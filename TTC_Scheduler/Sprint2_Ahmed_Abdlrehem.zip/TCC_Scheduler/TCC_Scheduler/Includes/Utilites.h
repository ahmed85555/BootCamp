/*
 * Utilites.h
 *
 * Created: 2/20/2019 1:39:39 PM
 *  Author: AVE-LAP-005
 */ 


#ifndef UTILITES_H_
#define UTILITES_H_
/* delays */
#define t_1000ms 1000
#define t_2000ms 2000
#define t_3000ms 3000
#define t_4000ms 4000
#define t_5000ms 5000
/*Numbers*/
#define NUM_ONE 1
#define NUM_ZERO 0
#define NUM_TWO  2
#define NUM_THREE 3
#define NUM_FOUR  4
#define NUM_SIX  6
#define NUM_SEVEN 7
#define NUM_EIGHT 8



#endif /* UTILITES_H_ */