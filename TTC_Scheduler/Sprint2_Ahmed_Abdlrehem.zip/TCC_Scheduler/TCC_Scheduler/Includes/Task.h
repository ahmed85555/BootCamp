/*
 * Task.h
 *
 * Created: 2/23/2019 4:37:27 PM
 *  Author: AVE-LAP-005
 */ 


#ifndef TASK_H_
#define TASK_H_

#define NO_OF_TASKS 3

void led1_task();
void led2_task();
void led3_task();



#endif /* TASK_H_ */